/*
  # Add upgrade requests and plan information

  1. New Tables
    - `upgrade_requests`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references profiles)
      - `plan_type` (text) - 'plus' or 'premium'
      - `status` (text) - 'pending', 'accepted', 'rejected'
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Modified Tables
    - `profiles`
      - Add `plan` column (text, default 'free')
      - Add `plan_updated_at` column (timestamptz)

  3. Security
    - Enable RLS on upgrade_requests
    - Restrict access to admin accounts only
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'plan'
  ) THEN
    ALTER TABLE profiles ADD COLUMN plan text DEFAULT 'free';
    ALTER TABLE profiles ADD COLUMN plan_updated_at timestamptz DEFAULT now();
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS upgrade_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  plan_type text NOT NULL CHECK (plan_type IN ('plus', 'premium')),
  status text DEFAULT 'pending' NOT NULL CHECK (status IN ('pending', 'accepted', 'rejected')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE upgrade_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Only admins can view upgrade requests"
  ON upgrade_requests FOR SELECT
  TO authenticated
  USING (
    auth.jwt()->>'email' IN ('treurmattheo@gmail.com') OR
    (SELECT username FROM profiles WHERE id = auth.uid()) IN ('Mattyou')
  );

CREATE POLICY "Only admins can update upgrade requests"
  ON upgrade_requests FOR UPDATE
  TO authenticated
  USING (
    auth.jwt()->>'email' IN ('treurmattheo@gmail.com') OR
    (SELECT username FROM profiles WHERE id = auth.uid()) IN ('Mattyou')
  )
  WITH CHECK (
    auth.jwt()->>'email' IN ('treurmattheo@gmail.com') OR
    (SELECT username FROM profiles WHERE id = auth.uid()) IN ('Mattyou')
  );

CREATE POLICY "Users can insert own upgrade requests"
  ON upgrade_requests FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view own upgrade requests"
  ON upgrade_requests FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id OR 
    auth.jwt()->>'email' IN ('treurmattheo@gmail.com') OR
    (SELECT username FROM profiles WHERE id = auth.uid()) IN ('Mattyou')
  );