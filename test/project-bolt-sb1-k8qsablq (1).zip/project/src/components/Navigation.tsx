import { Cloud, Home, Key, Settings, Send, LogOut, Zap, FileQuestion } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

type NavigationProps = {
  currentPage: string;
  onPageChange: (page: string) => void;
};

export default function Navigation({ currentPage, onPageChange }: NavigationProps) {
  const { signOut, profile, user } = useAuth();

  const isAdmin = user?.email === 'treurmattheo@gmail.com' || profile?.username === 'Mattyou';

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Home },
    { id: 'api-keys', label: 'API Keys', icon: Key },
    { id: 'plans', label: 'Plans', icon: Zap },
    { id: 'messages', label: 'Send & Inbox', icon: Send },
    { id: 'settings', label: 'Settings', icon: Settings },
    ...(isAdmin ? [{ id: 'requests', label: 'Requests', icon: FileQuestion }] : []),
  ];

  const handleSignOut = async () => {
    try {
      await signOut();
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + ' ' + sizes[i];
  };

  return (
    <nav className="bg-slate-900 shadow-2xl shadow-blue-500/10 h-screen w-64 fixed left-0 top-0 flex flex-col border-r border-slate-700">
      <div className="p-6 border-b border-slate-700">
        <div className="flex items-center mb-4">
          <Cloud className="w-8 h-8 text-blue-400 mr-2" />
          <h1 className="text-xl font-bold text-slate-50">Mattyou Cloud</h1>
        </div>
        <div className="bg-slate-800 border border-slate-700 rounded-lg p-3">
          <p className="text-xs text-slate-400 mb-1">Storage Used ({profile?.plan})</p>
          <div className="flex items-baseline gap-1">
            <span className="text-sm font-semibold text-slate-50">
              {formatBytes(profile?.storage_used || 0)}
            </span>
            <span className="text-xs text-slate-500">
              / {formatBytes(profile?.storage_limit || 10737418240)}
            </span>
          </div>
          <div className="mt-2 bg-slate-700 rounded-full h-2 overflow-hidden">
            <div
              className="bg-blue-500 h-full transition-all"
              style={{
                width: `${((profile?.storage_used || 0) / (profile?.storage_limit || 10737418240)) * 100}%`,
              }}
            />
          </div>
        </div>
      </div>

      <div className="flex-1 p-4 overflow-y-auto">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentPage === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onPageChange(item.id)}
              className={`w-full flex items-center px-4 py-3 rounded-lg mb-2 transition-all ${
                isActive
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/20'
                  : 'text-slate-400 hover:bg-slate-800 hover:text-slate-300'
              }`}
            >
              <Icon className="w-5 h-5 mr-3" />
              <span className="font-medium">{item.label}</span>
            </button>
          );
        })}
      </div>

      <div className="p-4 border-t border-slate-700">
        <div className="mb-3 px-2">
          <p className="text-xs text-slate-500">Logged in as</p>
          <p className="text-sm font-medium text-slate-50 truncate">
            @{profile?.username}
          </p>
        </div>
        <button
          onClick={handleSignOut}
          className="w-full flex items-center justify-center px-4 py-2 bg-red-950 text-red-400 rounded-lg hover:bg-red-900 transition-all border border-red-900"
        >
          <LogOut className="w-4 h-4 mr-2" />
          <span className="font-medium">Sign Out</span>
        </button>
      </div>
    </nav>
  );
}
