import { useState, useEffect } from 'react';
import { X, Download, Volume2, Play, Pause } from 'lucide-react';
import { File as FileType } from '../lib/supabase';
import { supabase } from '../lib/supabase';

type FilePreviewProps = {
  file: FileType | null;
  onClose: () => void;
};

export default function FilePreview({ file, onClose }: FilePreviewProps) {
  const [fileUrl, setFileUrl] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);

  useEffect(() => {
    if (!file) return;

    const getFileUrl = async () => {
      try {
        const { data } = await supabase.storage
          .from('files')
          .createSignedUrl(file.storage_path, 3600);

        if (data?.signedUrl) {
          setFileUrl(data.signedUrl);
        }
      } catch (error) {
        console.error('Error getting file URL:', error);
      } finally {
        setLoading(false);
      }
    };

    getFileUrl();
  }, [file]);

  if (!file) return null;

  const isImage = file.file_type.startsWith('image/');
  const isVideo = file.file_type.startsWith('video/');
  const isAudio = file.file_type.startsWith('audio/');
  const isPdf = file.file_type === 'application/pdf';

  const formatTime = (seconds: number) => {
    if (!seconds || isNaN(seconds)) return '0:00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleDownload = async () => {
    try {
      const { data, error } = await supabase.storage
        .from('files')
        .download(file.storage_path);

      if (error) throw error;

      const url = URL.createObjectURL(data);
      const a = document.createElement('a');
      a.href = url;
      a.download = file.filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Download error:', error);
      alert('Failed to download file');
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4 z-50">
      <div className="bg-slate-900 rounded-xl max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col border border-slate-700">
        <div className="flex items-center justify-between p-6 border-b border-slate-700">
          <div className="flex-1">
            <h3 className="text-xl font-bold text-slate-50">{file.filename}</h3>
            <p className="text-sm text-slate-400 mt-1">
              {(file.file_size / 1024 / 1024).toFixed(2)} MB
            </p>
          </div>
          <div className="flex gap-2 ml-4">
            <button
              onClick={handleDownload}
              className="p-2 text-blue-400 hover:bg-slate-800 rounded-lg transition-all"
              title="Download"
            >
              <Download className="w-5 h-5" />
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-300"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto bg-black flex items-center justify-center">
          {loading ? (
            <div className="text-center">
              <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
              <p className="text-slate-400">Loading file...</p>
            </div>
          ) : isImage ? (
            <img src={fileUrl} alt={file.filename} className="max-w-full max-h-full object-contain" />
          ) : isVideo ? (
            <video
              src={fileUrl}
              controls
              autoPlay
              className="max-w-full max-h-full"
              onLoadedMetadata={(e) => setDuration((e.target as HTMLVideoElement).duration)}
            />
          ) : isAudio ? (
            <div className="text-center w-full">
              <div className="bg-slate-800 rounded-lg p-8 inline-block">
                <Volume2 className="w-16 h-16 text-blue-400 mx-auto mb-4" />
                <p className="text-slate-50 mb-6 font-medium">{file.filename}</p>
                <audio
                  src={fileUrl}
                  controls
                  autoPlay
                  className="w-80 mb-4"
                  onLoadedMetadata={(e) => setDuration((e.target as HTMLAudioElement).duration)}
                  onTimeUpdate={(e) => setCurrentTime((e.target as HTMLAudioElement).currentTime)}
                  style={{
                    filter: 'brightness(0.9)',
                  }}
                />
                <div className="text-sm text-slate-400 text-center">
                  {formatTime(currentTime)} / {formatTime(duration)}
                </div>
              </div>
            </div>
          ) : isPdf ? (
            <div className="text-center text-slate-300">
              <p className="mb-4">PDF Preview</p>
              <p className="text-sm text-slate-400 mb-4">
                Click the download button to view this PDF file
              </p>
              <button
                onClick={handleDownload}
                className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition-all inline-flex items-center gap-2"
              >
                <Download className="w-4 h-4" />
                Download PDF
              </button>
            </div>
          ) : (
            <div className="text-center text-slate-300">
              <p className="mb-4">File Preview Not Available</p>
              <p className="text-sm text-slate-400 mb-4">
                This file type cannot be previewed in the browser
              </p>
              <button
                onClick={handleDownload}
                className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition-all inline-flex items-center gap-2"
              >
                <Download className="w-4 h-4" />
                Download File
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
