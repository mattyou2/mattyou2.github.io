import { useState, useEffect } from 'react';
import { Send, Inbox, Mail, FileText, Trash2, CheckCheck, X } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase, Message, Profile, File as FileType } from '../lib/supabase';

type MessageWithSender = Message & {
  sender?: Profile;
  file?: FileType;
};

export default function Messages() {
  const { user, profile } = useAuth();
  const [activeTab, setActiveTab] = useState<'inbox' | 'sent'>('inbox');
  const [messages, setMessages] = useState<MessageWithSender[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCompose, setShowCompose] = useState(false);
  const [recipientUsername, setRecipientUsername] = useState('');
  const [subject, setSubject] = useState('');
  const [content, setContent] = useState('');
  const [selectedFile, setSelectedFile] = useState<FileType | null>(null);
  const [userFiles, setUserFiles] = useState<FileType[]>([]);
  const [sending, setSending] = useState(false);
  const [selectedMessage, setSelectedMessage] = useState<MessageWithSender | null>(null);

  useEffect(() => {
    loadMessages();
    loadUserFiles();
  }, [user, activeTab]);

  const loadMessages = async () => {
    if (!user) return;

    setLoading(true);
    const query =
      activeTab === 'inbox'
        ? supabase.from('messages').select('*').eq('to_user_id', user.id)
        : supabase.from('messages').select('*').eq('from_user_id', user.id);

    const { data, error } = await query.order('created_at', { ascending: false });

    if (!error && data) {
      const messagesWithDetails = await Promise.all(
        data.map(async (msg) => {
          const senderId = activeTab === 'inbox' ? msg.from_user_id : msg.to_user_id;

          const { data: senderData } = await supabase
            .from('profiles')
            .select('*')
            .eq('id', senderId)
            .maybeSingle();

          let fileData = null;
          if (msg.file_id) {
            const { data: file } = await supabase
              .from('files')
              .select('*')
              .eq('id', msg.file_id)
              .maybeSingle();
            fileData = file;
          }

          return {
            ...msg,
            sender: senderData || undefined,
            file: fileData || undefined,
          };
        })
      );

      setMessages(messagesWithDetails);
    }
    setLoading(false);
  };

  const loadUserFiles = async () => {
    if (!user) return;

    const { data, error } = await supabase
      .from('files')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    if (!error && data) {
      setUserFiles(data);
    }
  };

  const sendMessage = async () => {
    if (!user || !recipientUsername.trim() || !subject.trim() || !content.trim()) {
      alert('Please fill in all required fields');
      return;
    }

    setSending(true);
    try {
      const { data: recipient } = await supabase
        .from('profiles')
        .select('*')
        .eq('username', recipientUsername.trim())
        .maybeSingle();

      if (!recipient) {
        throw new Error('User not found');
      }

      if (recipient.id === user.id) {
        throw new Error('Cannot send message to yourself');
      }

      const { error } = await supabase.from('messages').insert({
        from_user_id: user.id,
        to_user_id: recipient.id,
        subject,
        content,
        file_id: selectedFile?.id || null,
        read: false,
      });

      if (error) throw error;

      alert('Message sent successfully!');
      setShowCompose(false);
      setRecipientUsername('');
      setSubject('');
      setContent('');
      setSelectedFile(null);
      loadMessages();
    } catch (error) {
      console.error('Error sending message:', error);
      alert(error instanceof Error ? error.message : 'Failed to send message');
    } finally {
      setSending(false);
    }
  };

  const markAsRead = async (messageId: string) => {
    try {
      await supabase.from('messages').update({ read: true }).eq('id', messageId);
      loadMessages();
    } catch (error) {
      console.error('Error marking as read:', error);
    }
  };

  const deleteMessage = async (messageId: string) => {
    if (!confirm('Delete this message?')) return;

    try {
      const { error } = await supabase.from('messages').delete().eq('id', messageId);

      if (error) throw error;

      setSelectedMessage(null);
      loadMessages();
    } catch (error) {
      console.error('Error deleting message:', error);
      alert('Failed to delete message');
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;
    return date.toLocaleDateString();
  };

  const unreadCount = messages.filter((m) => !m.read && activeTab === 'inbox').length;

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-50 mb-2">Send & Inbox</h1>
        <p className="text-slate-400">Send messages and files to other Mattyou Cloud users</p>
      </div>

      <div className="flex gap-4 mb-6">
        <button
          onClick={() => setShowCompose(true)}
          className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg flex items-center transition-all"
        >
          <Send className="w-5 h-5 mr-2" />
          Compose Message
        </button>

        <div className="flex bg-slate-900 border border-slate-700 rounded-lg overflow-hidden">
          <button
            onClick={() => setActiveTab('inbox')}
            className={`px-6 py-3 flex items-center transition-all ${
              activeTab === 'inbox'
                ? 'bg-blue-600 text-white'
                : 'text-slate-400 hover:text-slate-300 hover:bg-slate-800'
            }`}
          >
            <Inbox className="w-5 h-5 mr-2" />
            Inbox
            {unreadCount > 0 && (
              <span className="ml-2 bg-red-500 text-white text-xs px-2 py-0.5 rounded-full">
                {unreadCount}
              </span>
            )}
          </button>
          <button
            onClick={() => setActiveTab('sent')}
            className={`px-6 py-3 flex items-center transition-all ${
              activeTab === 'sent'
                ? 'bg-blue-600 text-white'
                : 'text-slate-400 hover:text-slate-300 hover:bg-slate-800'
            }`}
          >
            <Send className="w-5 h-5 mr-2" />
            Sent
          </button>
        </div>
      </div>

      {loading ? (
        <div className="text-center py-12 text-slate-400">Loading messages...</div>
      ) : messages.length === 0 ? (
        <div className="text-center py-12 bg-slate-900 rounded-lg border border-slate-700">
          <Mail className="w-16 h-16 text-slate-600 mx-auto mb-4" />
          <p className="text-slate-50">
            {activeTab === 'inbox'
              ? 'No messages in your inbox'
              : "You haven't sent any messages yet"}
          </p>
        </div>
      ) : (
        <div className="bg-slate-900 rounded-lg shadow-lg border border-slate-700 overflow-hidden">
          <div className="divide-y divide-slate-700">
            {messages.map((message) => (
              <div
                key={message.id}
                onClick={() => {
                  setSelectedMessage(message);
                  if (activeTab === 'inbox' && !message.read) {
                    markAsRead(message.id);
                  }
                }}
                className={`p-4 hover:bg-slate-800 cursor-pointer transition-colors ${
                  !message.read && activeTab === 'inbox' ? 'bg-slate-800' : ''
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <p className="font-semibold text-slate-50">
                        {activeTab === 'inbox' ? 'From' : 'To'}: @{message.sender?.username}
                      </p>
                      {!message.read && activeTab === 'inbox' && (
                        <span className="bg-blue-600 text-white text-xs px-2 py-0.5 rounded-full">
                          New
                        </span>
                      )}
                      {message.file && (
                        <span className="flex items-center text-xs text-slate-400">
                          <FileText className="w-3 h-3 mr-1" />
                          Attachment
                        </span>
                      )}
                    </div>
                    <p className="text-sm font-medium text-slate-50 mb-1">{message.subject}</p>
                    <p className="text-sm text-slate-400 line-clamp-2">{message.content}</p>
                  </div>
                  <div className="text-xs text-slate-500 ml-4">{formatDate(message.created_at)}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {showCompose && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-slate-900 rounded-xl p-6 max-w-2xl w-full max-h-[90vh] overflow-y-auto border border-slate-700">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold text-slate-50">Compose Message</h3>
              <button
                onClick={() => setShowCompose(false)}
                className="text-slate-400 hover:text-slate-300"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Recipient Username
                </label>
                <input
                  type="text"
                  value={recipientUsername}
                  onChange={(e) => setRecipientUsername(e.target.value)}
                  placeholder="@username"
                  className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-slate-50 focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Subject</label>
                <input
                  type="text"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="Message subject"
                  className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-slate-50 focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Message</label>
                <textarea
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Type your message here..."
                  rows={6}
                  className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-slate-50 focus:ring-2 focus:ring-blue-500 outline-none resize-none"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Attach File (Optional)
                </label>
                <select
                  value={selectedFile?.id || ''}
                  onChange={(e) => {
                    const file = userFiles.find((f) => f.id === e.target.value);
                    setSelectedFile(file || null);
                  }}
                  className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-slate-50 focus:ring-2 focus:ring-blue-500 outline-none"
                >
                  <option value="">No attachment</option>
                  {userFiles.map((file) => (
                    <option key={file.id} value={file.id}>
                      {file.filename}
                    </option>
                  ))}
                </select>
              </div>

              <button
                onClick={sendMessage}
                disabled={sending}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg flex items-center justify-center transition-all disabled:opacity-50"
              >
                <Send className="w-5 h-5 mr-2" />
                {sending ? 'Sending...' : 'Send Message'}
              </button>
            </div>
          </div>
        </div>
      )}

      {selectedMessage && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-slate-900 rounded-xl p-6 max-w-2xl w-full max-h-[90vh] overflow-y-auto border border-slate-700">
            <div className="flex items-start justify-between mb-6">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  {!selectedMessage.read && activeTab === 'inbox' && (
                    <CheckCheck className="w-5 h-5 text-blue-400" />
                  )}
                  <h3 className="text-2xl font-bold text-slate-50">{selectedMessage.subject}</h3>
                </div>
                <p className="text-sm text-slate-400">
                  {activeTab === 'inbox' ? 'From' : 'To'}: @{selectedMessage.sender?.username}
                </p>
                <p className="text-xs text-slate-500">{formatDate(selectedMessage.created_at)}</p>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => deleteMessage(selectedMessage.id)}
                  className="p-2 text-red-400 hover:bg-slate-800 rounded-lg transition-all"
                  title="Delete"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
                <button
                  onClick={() => setSelectedMessage(null)}
                  className="p-2 text-slate-400 hover:text-slate-300"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>

            <div className="border-t border-slate-700 pt-4 mb-4">
              <p className="text-slate-300 whitespace-pre-wrap">{selectedMessage.content}</p>
            </div>

            {selectedMessage.file && (
              <div className="bg-slate-800 rounded-lg p-4 border border-slate-700">
                <div className="flex items-center">
                  <FileText className="w-5 h-5 text-slate-500 mr-3" />
                  <div className="flex-1">
                    <p className="text-sm font-medium text-slate-50">
                      {selectedMessage.file.filename}
                    </p>
                    <p className="text-xs text-slate-500">
                      {(selectedMessage.file.file_size / 1024).toFixed(2)} KB
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
