import { useState, useEffect } from 'react';
import { Upload, Download, Trash2, Share2, Sparkles, FileText, Image as ImageIcon, Video, Music, File as FileIcon, X, Eye } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase, File as FileType } from '../lib/supabase';
import FilePreview from '../components/FilePreview';

export default function Dashboard() {
  const { user, profile, refreshProfile } = useAuth();
  const [files, setFiles] = useState<FileType[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [shareModalFile, setShareModalFile] = useState<FileType | null>(null);
  const [previewFile, setPreviewFile] = useState<FileType | null>(null);
  const [maxUses, setMaxUses] = useState(10);
  const [shareLink, setShareLink] = useState('');
  const [sortBy, setSortBy] = useState<'name' | 'date' | 'size' | 'type'>('date');

  useEffect(() => {
    loadFiles();
  }, [user]);

  const loadFiles = async () => {
    if (!user) return;

    const { data, error } = await supabase
      .from('files')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    if (!error && data) {
      setFiles(data);
    }
    setLoading(false);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || !user || !profile) return;

    const file = e.target.files[0];
    const fileSize = file.size;

    if (profile.storage_used + fileSize > profile.storage_limit) {
      alert('Storage limit exceeded!');
      return;
    }

    setUploading(true);

    try {
      const fileName = `${user.id}/${Date.now()}-${file.name}`;

      const { error: uploadError } = await supabase.storage
        .from('files')
        .upload(fileName, file);

      if (uploadError) throw uploadError;

      const { error: dbError } = await supabase.from('files').insert({
        user_id: user.id,
        filename: file.name,
        file_size: fileSize,
        file_type: file.type || 'application/octet-stream',
        storage_path: fileName,
      });

      if (dbError) throw dbError;

      await loadFiles();
      await refreshProfile();
    } catch (error) {
      console.error('Upload error:', error);
      alert('Failed to upload file');
    } finally {
      setUploading(false);
      e.target.value = '';
    }
  };

  const handleDelete = async (file: FileType) => {
    if (!confirm(`Delete ${file.filename}?`)) return;

    try {
      const { error: storageError } = await supabase.storage
        .from('files')
        .remove([file.storage_path]);

      if (storageError) throw storageError;

      const { error: dbError } = await supabase
        .from('files')
        .delete()
        .eq('id', file.id);

      if (dbError) throw dbError;

      await loadFiles();
      await refreshProfile();
    } catch (error) {
      console.error('Delete error:', error);
      alert('Failed to delete file');
    }
  };

  const handleDownload = async (file: FileType) => {
    try {
      const { data, error } = await supabase.storage
        .from('files')
        .download(file.storage_path);

      if (error) throw error;

      const url = URL.createObjectURL(data);
      const a = document.createElement('a');
      a.href = url;
      a.download = file.filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Download error:', error);
      alert('Failed to download file');
    }
  };

  const handleShare = async () => {
    if (!shareModalFile || !user) return;

    try {
      const shareToken = crypto.randomUUID();

      const { error } = await supabase.from('file_shares').insert({
        file_id: shareModalFile.id,
        user_id: user.id,
        share_token: shareToken,
        max_uses: maxUses,
        current_uses: 0,
      });

      if (error) throw error;

      const link = `${window.location.origin}/share/${shareToken}`;
      setShareLink(link);
    } catch (error) {
      console.error('Share error:', error);
      alert('Failed to create share link');
    }
  };

  const sortFiles = (filesToSort: FileType[]) => {
    const sorted = [...filesToSort];
    switch (sortBy) {
      case 'name':
        return sorted.sort((a, b) => a.filename.localeCompare(b.filename));
      case 'date':
        return sorted.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
      case 'size':
        return sorted.sort((a, b) => b.file_size - a.file_size);
      case 'type':
        return sorted.sort((a, b) => a.file_type.localeCompare(b.file_type));
      default:
        return sorted;
    }
  };

  const getFileIcon = (fileType: string) => {
    if (fileType.startsWith('image/')) return ImageIcon;
    if (fileType.startsWith('video/')) return Video;
    if (fileType.startsWith('audio/')) return Music;
    if (fileType.startsWith('text/')) return FileText;
    return FileIcon;
  };

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + ' ' + sizes[i];
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  const sortedFiles = sortFiles(files);

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-50 mb-2">My Files</h1>
        <p className="text-slate-400">Manage your cloud storage with Mattyou AI</p>
      </div>

      <div className="flex gap-4 mb-6">
        <label className="flex-1">
          <input
            type="file"
            onChange={handleFileUpload}
            disabled={uploading}
            className="hidden"
          />
          <div className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg cursor-pointer flex items-center justify-center transition-all disabled:opacity-50">
            <Upload className="w-5 h-5 mr-2" />
            {uploading ? 'Uploading...' : 'Upload File'}
          </div>
        </label>

        <div className="flex items-center gap-2 bg-slate-900 border border-slate-700 rounded-lg px-4">
          <Sparkles className="w-5 h-5 text-blue-400" />
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="bg-transparent outline-none text-slate-300 font-medium"
          >
            <option value="date">Sort by Date</option>
            <option value="name">Sort by Name</option>
            <option value="size">Sort by Size</option>
            <option value="type">Sort by Type</option>
          </select>
        </div>
      </div>

      {loading ? (
        <div className="text-center py-12 text-slate-400">Loading files...</div>
      ) : files.length === 0 ? (
        <div className="text-center py-12 bg-slate-900 rounded-lg border border-slate-700">
          <Upload className="w-16 h-16 text-slate-600 mx-auto mb-4" />
          <p className="text-slate-50">No files yet. Upload your first file!</p>
        </div>
      ) : (
        <div className="bg-slate-900 rounded-lg shadow-lg border border-slate-700 overflow-hidden">
          <table className="w-full">
            <thead className="bg-slate-800 border-b border-slate-700">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-slate-400 uppercase">Name</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-slate-400 uppercase">Size</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-slate-400 uppercase">Date</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-slate-400 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-700">
              {sortedFiles.map((file) => {
                const Icon = getFileIcon(file.file_type);
                return (
                  <tr key={file.id} className="hover:bg-slate-800 transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex items-center">
                        <Icon className="w-5 h-5 text-slate-500 mr-3" />
                        <span className="text-sm font-medium text-slate-50">{file.filename}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-400">{formatBytes(file.file_size)}</td>
                    <td className="px-6 py-4 text-sm text-slate-400">{formatDate(file.created_at)}</td>
                    <td className="px-6 py-4">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => setPreviewFile(file)}
                          className="p-2 text-purple-400 hover:bg-slate-800 rounded-lg transition-all"
                          title="Preview"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDownload(file)}
                          className="p-2 text-blue-400 hover:bg-slate-800 rounded-lg transition-all"
                          title="Download"
                        >
                          <Download className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => {
                            setShareModalFile(file);
                            setShareLink('');
                            setMaxUses(10);
                          }}
                          className="p-2 text-green-400 hover:bg-slate-800 rounded-lg transition-all"
                          title="Share"
                        >
                          <Share2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDelete(file)}
                          className="p-2 text-red-400 hover:bg-slate-800 rounded-lg transition-all"
                          title="Delete"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {shareModalFile && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-slate-900 rounded-xl p-6 max-w-md w-full border border-slate-700">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold text-slate-50">Share File</h3>
              <button
                onClick={() => setShareModalFile(null)}
                className="text-slate-400 hover:text-slate-300"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-slate-300 mb-4">
              Share: <strong>{shareModalFile.filename}</strong>
            </p>

            <div className="mb-4">
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Maximum Uses
              </label>
              <input
                type="number"
                min="1"
                value={maxUses}
                onChange={(e) => setMaxUses(parseInt(e.target.value) || 1)}
                className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-slate-50 focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>

            {!shareLink ? (
              <button
                onClick={handleShare}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg transition-all"
              >
                Generate Share Link
              </button>
            ) : (
              <div className="space-y-3">
                <div className="bg-slate-800 p-3 rounded-lg border border-slate-700">
                  <p className="text-xs text-slate-400 mb-1">Share Link:</p>
                  <p className="text-sm font-mono text-slate-300 break-all">{shareLink}</p>
                </div>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(shareLink);
                    alert('Link copied to clipboard!');
                  }}
                  className="w-full bg-green-600 hover:bg-green-700 text-white py-2 rounded-lg transition-all"
                >
                  Copy Link
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      <FilePreview file={previewFile} onClose={() => setPreviewFile(null)} />
    </div>
  );
}
