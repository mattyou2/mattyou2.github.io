import { useState, useEffect } from 'react';
import { Key, Copy, Trash2, Plus, Code, X } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase, ApiKey } from '../lib/supabase';

export default function ApiKeys() {
  const { user } = useAuth();
  const [apiKeys, setApiKeys] = useState<ApiKey[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [keyName, setKeyName] = useState('My API Key');
  const [permissions, setPermissions] = useState({
    read: true,
    write: true,
    delete: false,
    edit: false,
  });
  const [creating, setCreating] = useState(false);
  const [copiedKeyId, setCopiedKeyId] = useState<string>('');
  const [showScript, setShowScript] = useState<string>('');

  useEffect(() => {
    loadApiKeys();
  }, [user]);

  const loadApiKeys = async () => {
    if (!user) return;

    const { data, error } = await supabase
      .from('api_keys')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    if (!error && data) {
      setApiKeys(data);
    }
    setLoading(false);
  };

  const generateApiKey = () => {
    return `sk_${user?.id?.slice(0, 8)}_${Math.random().toString(36).substring(2, 15)}${Math.random().toString(36).substring(2, 15)}`;
  };

  const handleCreateKey = async () => {
    if (!user || !keyName.trim()) {
      alert('Please enter a key name');
      return;
    }

    setCreating(true);
    try {
      const newKey = generateApiKey();

      const { error } = await supabase.from('api_keys').insert({
        user_id: user.id,
        key: newKey,
        name: keyName,
        permissions: permissions,
      });

      if (error) throw error;

      await loadApiKeys();
      setShowModal(false);
      setKeyName('My API Key');
      setPermissions({
        read: true,
        write: true,
        delete: false,
        edit: false,
      });
    } catch (error) {
      console.error('Error creating API key:', error);
      alert('Failed to create API key');
    } finally {
      setCreating(false);
    }
  };

  const handleDeleteKey = async (keyId: string) => {
    if (!confirm('Delete this API key?')) return;

    try {
      const { error } = await supabase.from('api_keys').delete().eq('id', keyId);

      if (error) throw error;

      await loadApiKeys();
    } catch (error) {
      console.error('Error deleting API key:', error);
      alert('Failed to delete API key');
    }
  };

  const copyToClipboard = (text: string, keyId: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKeyId(keyId);
    setTimeout(() => setCopiedKeyId(''), 2000);
  };

  const generateHTMLScript = (apiKey: string) => {
    return `<!DOCTYPE html>
<html>
<head>
    <title>Mattyou Cloud API</title>
</head>
<body>
    <h1>Mattyou Cloud API Client</h1>
    <p>Your API Key: <code>${apiKey}</code></p>

    <h2>Example Usage</h2>

    <h3>Upload File</h3>
    <pre><code>
const formData = new FormData();
formData.append('file', fileInput.files[0]);

const response = await fetch(
    'https://api.mattyoucloud.com/v1/files/upload',
    {
        method: 'POST',
        headers: {
            'Authorization': 'Bearer ${apiKey}'
        },
        body: formData
    }
);
const result = await response.json();
console.log('Uploaded:', result);
    </code></pre>

    <h3>List Files</h3>
    <pre><code>
const response = await fetch(
    'https://api.mattyoucloud.com/v1/files',
    {
        headers: {
            'Authorization': 'Bearer ${apiKey}'
        }
    }
);
const files = await response.json();
console.log('Files:', files);
    </code></pre>

    <h3>Download File</h3>
    <pre><code>
const response = await fetch(
    'https://api.mattyoucloud.com/v1/files/{fileId}/download',
    {
        headers: {
            'Authorization': 'Bearer ${apiKey}'
        }
    }
);
const blob = await response.blob();
const url = URL.createObjectURL(blob);
const a = document.createElement('a');
a.href = url;
a.download = 'filename.ext';
a.click();
    </code></pre>

    <h3>Delete File</h3>
    <pre><code>
const response = await fetch(
    'https://api.mattyoucloud.com/v1/files/{fileId}',
    {
        method: 'DELETE',
        headers: {
            'Authorization': 'Bearer ${apiKey}'
        }
    }
);
const result = await response.json();
console.log('Deleted:', result);
    </code></pre>

    <h3>Edit File Metadata</h3>
    <pre><code>
const response = await fetch(
    'https://api.mattyoucloud.com/v1/files/{fileId}',
    {
        method: 'PUT',
        headers: {
            'Authorization': 'Bearer ${apiKey}',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            filename: 'new-name.ext'
        })
    }
);
const result = await response.json();
console.log('Updated:', result);
    </code></pre>

    <script>
        console.log('Replace {fileId} with actual file ID from list endpoint');
    </script>
</body>
</html>`;
  };

  if (loading) {
    return (
      <div className="p-8">
        <div className="text-center py-12 text-slate-400">Loading API keys...</div>
      </div>
    );
  }

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-50 mb-2">API Keys</h1>
        <p className="text-slate-400">Create and manage API keys for programmatic access</p>
      </div>

      <button
        onClick={() => setShowModal(true)}
        className="mb-6 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg flex items-center transition-all"
      >
        <Plus className="w-5 h-5 mr-2" />
        Generate API Key
      </button>

      {apiKeys.length === 0 ? (
        <div className="text-center py-12 bg-slate-900 rounded-lg border border-slate-700">
          <Key className="w-16 h-16 text-slate-600 mx-auto mb-4" />
          <p className="text-slate-50">No API keys yet</p>
          <p className="text-slate-400">Create one to get started with the API</p>
        </div>
      ) : (
        <div className="space-y-4">
          {apiKeys.map((apiKey) => (
            <div
              key={apiKey.id}
              className="bg-slate-900 border border-slate-700 rounded-lg p-6 hover:border-slate-600 transition-all"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-slate-50 mb-2">{apiKey.name}</h3>
                  <div className="font-mono text-sm bg-slate-800 text-slate-300 px-3 py-2 rounded inline-block break-all">
                    {apiKey.key}
                  </div>
                  <div className="mt-3 text-xs text-slate-500">
                    Created: {new Date(apiKey.created_at).toLocaleDateString()}
                    {apiKey.last_used && ` • Last used: ${new Date(apiKey.last_used).toLocaleDateString()}`}
                  </div>
                </div>
                <div className="flex gap-2 ml-4">
                  <button
                    onClick={() => copyToClipboard(apiKey.key, apiKey.id)}
                    className="p-2 text-blue-400 hover:bg-slate-800 rounded-lg transition-all"
                    title="Copy API Key"
                  >
                    <Copy className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => setShowScript(apiKey.id)}
                    className="p-2 text-green-400 hover:bg-slate-800 rounded-lg transition-all"
                    title="View HTML Script"
                  >
                    <Code className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => handleDeleteKey(apiKey.id)}
                    className="p-2 text-red-400 hover:bg-slate-800 rounded-lg transition-all"
                    title="Delete"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>

              <div className="flex flex-wrap gap-2">
                {apiKey.permissions.read && (
                  <span className="inline-block px-3 py-1 bg-blue-950 text-blue-300 rounded-full text-xs font-medium">
                    Read
                  </span>
                )}
                {apiKey.permissions.write && (
                  <span className="inline-block px-3 py-1 bg-green-950 text-green-300 rounded-full text-xs font-medium">
                    Write
                  </span>
                )}
                {apiKey.permissions.edit && (
                  <span className="inline-block px-3 py-1 bg-amber-950 text-amber-300 rounded-full text-xs font-medium">
                    Edit
                  </span>
                )}
                {apiKey.permissions.delete && (
                  <span className="inline-block px-3 py-1 bg-red-950 text-red-300 rounded-full text-xs font-medium">
                    Delete
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {copiedKeyId && (
        <div className="fixed bottom-4 right-4 bg-green-600 text-white px-4 py-2 rounded-lg flex items-center gap-2">
          <Copy className="w-4 h-4" />
          Copied to clipboard!
        </div>
      )}

      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-slate-900 rounded-xl p-6 max-w-md w-full border border-slate-700 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-slate-50">Generate API Key</h3>
              <button
                onClick={() => setShowModal(false)}
                className="text-slate-400 hover:text-slate-300"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Key Name</label>
                <input
                  type="text"
                  value={keyName}
                  onChange={(e) => setKeyName(e.target.value)}
                  className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-slate-50 focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>

              <div className="space-y-3">
                <label className="block text-sm font-medium text-slate-300">Permissions</label>

                <label className="flex items-center gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={permissions.read}
                    onChange={(e) => setPermissions({ ...permissions, read: e.target.checked })}
                    className="w-4 h-4 accent-blue-500"
                  />
                  <span className="text-slate-300">Read files</span>
                </label>

                <label className="flex items-center gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={permissions.write}
                    onChange={(e) => setPermissions({ ...permissions, write: e.target.checked })}
                    className="w-4 h-4 accent-blue-500"
                  />
                  <span className="text-slate-300">Upload files</span>
                </label>

                <label className="flex items-center gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={permissions.edit}
                    onChange={(e) => setPermissions({ ...permissions, edit: e.target.checked })}
                    className="w-4 h-4 accent-blue-500"
                  />
                  <span className="text-slate-300">Edit files</span>
                </label>

                <label className="flex items-center gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={permissions.delete}
                    onChange={(e) => setPermissions({ ...permissions, delete: e.target.checked })}
                    className="w-4 h-4 accent-blue-500"
                  />
                  <span className="text-slate-300">Delete files</span>
                </label>
              </div>

              <button
                onClick={handleCreateKey}
                disabled={creating}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg transition-all disabled:opacity-50"
              >
                {creating ? 'Creating...' : 'Generate Key'}
              </button>
            </div>
          </div>
        </div>
      )}

      {showScript && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-slate-900 rounded-xl max-w-2xl w-full border border-slate-700 max-h-[90vh] overflow-hidden flex flex-col">
            <div className="flex items-center justify-between p-6 border-b border-slate-700">
              <h3 className="text-xl font-bold text-slate-50">HTML Script Template</h3>
              <button
                onClick={() => setShowScript('')}
                className="text-slate-400 hover:text-slate-300"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto">
              <pre className="bg-slate-800 text-slate-50 p-6 text-sm overflow-x-auto">
                {generateHTMLScript(apiKeys.find((k) => k.id === showScript)?.key || '')}
              </pre>
            </div>

            <div className="p-6 border-t border-slate-700 flex gap-3">
              <button
                onClick={() => {
                  const script = generateHTMLScript(apiKeys.find((k) => k.id === showScript)?.key || '');
                  const blob = new Blob([script], { type: 'text/html' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = 'mattyou-cloud-api.html';
                  a.click();
                  URL.revokeObjectURL(url);
                }}
                className="flex-1 bg-green-600 hover:bg-green-700 text-white py-2 rounded-lg transition-all"
              >
                Download Script
              </button>
              <button
                onClick={() => setShowScript('')}
                className="flex-1 bg-slate-700 hover:bg-slate-600 text-slate-50 py-2 rounded-lg transition-all"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
