import { useState, useEffect } from 'react';
import { Settings as SettingsIcon, Sparkles, Save, Image as ImageIcon } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase, AiSettings } from '../lib/supabase';

export default function Settings() {
  const { user } = useAuth();
  const [settings, setSettings] = useState<AiSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    loadSettings();
  }, [user]);

  const loadSettings = async () => {
    if (!user) return;

    const { data, error } = await supabase
      .from('ai_settings')
      .select('*')
      .eq('user_id', user.id)
      .maybeSingle();

    if (!error && data) {
      setSettings(data);
    } else if (!data) {
      const defaultSettings = {
        user_id: user.id,
        sorting_enabled: true,
        image_generation_enabled: true,
        watermark_text: 'Mattyou AI',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };
      const { data: newData, error: insertError } = await supabase
        .from('ai_settings')
        .insert(defaultSettings)
        .select()
        .single();

      if (!insertError && newData) {
        setSettings(newData);
      }
    }
    setLoading(false);
  };

  const saveSettings = async () => {
    if (!user || !settings) return;

    setSaving(true);
    try {
      const { error } = await supabase
        .from('ai_settings')
        .update({
          sorting_enabled: settings.sorting_enabled,
          image_generation_enabled: settings.image_generation_enabled,
          watermark_text: settings.watermark_text,
          updated_at: new Date().toISOString(),
        })
        .eq('user_id', user.id);

      if (error) throw error;

      alert('Settings saved successfully!');
    } catch (error) {
      console.error('Error saving settings:', error);
      alert('Failed to save settings');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="p-8">
        <div className="text-center py-12 text-gray-500">Loading settings...</div>
      </div>
    );
  }

  if (!settings) {
    return (
      <div className="p-8">
        <div className="text-center py-12 text-gray-500">Failed to load settings</div>
      </div>
    );
  }

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-50 mb-2">Settings</h1>
        <p className="text-slate-400">Configure Mattyou AI and your preferences</p>
      </div>

      <div className="max-w-2xl space-y-6">
        <div className="bg-slate-900 rounded-lg shadow-lg border border-slate-700 p-6">
          <div className="flex items-center mb-6">
            <Sparkles className="w-6 h-6 text-blue-400 mr-3" />
            <h2 className="text-xl font-semibold text-slate-50">Mattyou AI Features</h2>
          </div>

          <div className="space-y-6">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <h3 className="font-medium text-slate-50 mb-1">Smart File Sorting</h3>
                <p className="text-sm text-slate-400">
                  Allow Mattyou AI to automatically sort and organize your files by type, date, and relevance
                </p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer ml-4">
                <input
                  type="checkbox"
                  checked={settings.sorting_enabled}
                  onChange={(e) =>
                    setSettings({ ...settings, sorting_enabled: e.target.checked })
                  }
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-500 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-600 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>

            <div className="border-t border-slate-700 pt-6">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h3 className="font-medium text-slate-50 mb-1">AI Image Generation</h3>
                  <p className="text-sm text-slate-400">
                    Enable Mattyou AI to generate images with automatic watermarking
                  </p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer ml-4">
                  <input
                    type="checkbox"
                    checked={settings.image_generation_enabled}
                    onChange={(e) =>
                      setSettings({
                        ...settings,
                        image_generation_enabled: e.target.checked,
                      })
                    }
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-500 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-600 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                </label>
              </div>

              {settings.image_generation_enabled && (
                <div className="mt-4">
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Watermark Text (Read-Only)
                  </label>
                  <div className="relative">
                    <ImageIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-500" />
                    <input
                      type="text"
                      value={settings.watermark_text}
                      disabled
                      className="w-full pl-10 pr-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-slate-300 cursor-not-allowed"
                    />
                  </div>
                  <p className="text-xs text-slate-500 mt-2">
                    Watermark is set by Mattyou and cannot be changed
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-r from-blue-950 to-blue-900 rounded-lg p-6 border border-blue-800">
          <div className="flex items-start">
            <div className="flex-shrink-0">
              <Sparkles className="w-6 h-6 text-blue-400" />
            </div>
            <div className="ml-3">
              <h3 className="text-sm font-medium text-blue-50">About Mattyou AI</h3>
              <div className="mt-2 text-sm text-blue-200">
                <p>
                  Mattyou AI is your intelligent cloud assistant, designed to help you organize and manage your files efficiently. With advanced sorting capabilities and image generation features, it makes your cloud experience smarter and more productive.
                </p>
              </div>
            </div>
          </div>
        </div>

        <button
          onClick={saveSettings}
          disabled={saving}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg flex items-center justify-center transition-all disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Save className="w-5 h-5 mr-2" />
          {saving ? 'Saving...' : 'Save Settings'}
        </button>
      </div>
    </div>
  );
}
