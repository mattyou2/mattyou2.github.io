import { useState } from 'react';
import { Check, Zap, Send, X } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';

const PLANS = [
  {
    id: 'free',
    name: 'Free',
    storage: 10,
    price: '0',
    features: [
      'Up to 10GB storage',
      'File upload and download',
      'File sharing with limits',
      'Basic file management',
      'Send messages to other users',
    ],
  },
  {
    id: 'plus',
    name: 'Mattyou Cloud Plus',
    storage: 50,
    price: '4.99',
    features: [
      'Up to 50GB storage',
      'All Free features',
      'Unlimited file sharing',
      'Advanced sorting',
      'AI image generation',
      'Priority support',
    ],
  },
  {
    id: 'premium',
    name: 'Mattyou Cloud Premium',
    storage: 1000,
    price: '9.99',
    features: [
      'Up to 1TB storage',
      'All Plus features',
      'Unlimited everything',
      'Priority support',
      'Advanced AI features',
      'Custom watermark options',
    ],
  },
];

export default function Plans() {
  const { user, profile, refreshProfile } = useAuth();
  const [selectedPlan, setSelectedPlan] = useState<string>('');
  const [showModal, setShowModal] = useState(false);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  const currentPlan = PLANS.find((p) => p.id === profile?.plan);

  const handleUpgradeClick = (planId: string) => {
    setSelectedPlan(planId);
    setShowModal(true);
    setMessage('');
  };

  const handleSubmitRequest = async () => {
    if (!user || !selectedPlan || selectedPlan === profile?.plan) return;

    setLoading(true);
    try {
      const { error } = await supabase.from('upgrade_requests').insert({
        user_id: user.id,
        plan_type: selectedPlan,
        status: 'pending',
      });

      if (error) throw error;

      setMessage('Upgrade request submitted! Admins will review your request.');
      setTimeout(() => {
        setShowModal(false);
        setSelectedPlan('');
        setMessage('');
      }, 2000);
    } catch (error) {
      console.error('Error submitting upgrade request:', error);
      setMessage('Failed to submit upgrade request');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-8">
      <div className="mb-12">
        <h1 className="text-3xl font-bold text-slate-50 mb-2">Plans & Pricing</h1>
        <p className="text-slate-400">Choose the perfect plan for your needs</p>
      </div>

      {currentPlan && (
        <div className="bg-gradient-to-r from-blue-950 to-blue-900 rounded-lg p-6 mb-12 border border-blue-800">
          <div className="flex items-center gap-3">
            <Zap className="w-6 h-6 text-yellow-400" />
            <div>
              <p className="text-blue-200">Your current plan</p>
              <p className="text-2xl font-bold text-blue-50">{currentPlan.name}</p>
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {PLANS.map((plan) => {
          const isCurrentPlan = profile?.plan === plan.id;
          return (
            <div
              key={plan.id}
              className={`rounded-xl overflow-hidden transition-all ${
                isCurrentPlan
                  ? 'bg-blue-600 shadow-2xl shadow-blue-500/30 border-2 border-blue-400'
                  : 'bg-slate-900 border border-slate-700 hover:border-slate-600'
              }`}
            >
              <div className="p-8">
                <h3 className={`text-2xl font-bold mb-2 ${isCurrentPlan ? 'text-white' : 'text-slate-50'}`}>
                  {plan.name}
                </h3>
                <div className="mb-6">
                  <span className={`text-4xl font-bold ${isCurrentPlan ? 'text-white' : 'text-slate-50'}`}>
                    ${plan.price}
                  </span>
                  <span className={isCurrentPlan ? 'text-blue-100' : 'text-slate-400'}>/month</span>
                </div>

                <div className={`text-sm font-semibold mb-6 ${isCurrentPlan ? 'text-blue-100' : 'text-blue-400'}`}>
                  {plan.storage}GB Storage
                </div>

                <button
                  onClick={() => handleUpgradeClick(plan.id)}
                  disabled={isCurrentPlan || loading}
                  className={`w-full py-3 rounded-lg font-medium transition-all mb-8 ${
                    isCurrentPlan
                      ? 'bg-white text-blue-600 cursor-default'
                      : 'bg-blue-600 hover:bg-blue-700 text-white disabled:opacity-50'
                  }`}
                >
                  {isCurrentPlan ? 'Current Plan' : 'Choose Plan'}
                </button>

                <div className="space-y-3">
                  {plan.features.map((feature, idx) => (
                    <div key={idx} className="flex items-start gap-3">
                      <Check className={`w-5 h-5 flex-shrink-0 mt-0.5 ${isCurrentPlan ? 'text-white' : 'text-green-400'}`} />
                      <span className={isCurrentPlan ? 'text-white' : 'text-slate-300 text-sm'}>{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {showModal && selectedPlan && selectedPlan !== profile?.plan && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-slate-900 rounded-xl p-6 max-w-md w-full border border-slate-700">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-slate-50">Upgrade Request</h3>
              <button
                onClick={() => setShowModal(false)}
                className="text-slate-400 hover:text-slate-300"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-slate-300 mb-4">
              Request an upgrade to <strong>{PLANS.find((p) => p.id === selectedPlan)?.name}</strong>
            </p>

            <div className="bg-slate-800 rounded-lg p-4 mb-6 border border-slate-700">
              <p className="text-slate-400 text-sm mb-2">Plan Details</p>
              <div className="space-y-1">
                <p className="text-slate-50 font-medium">
                  {PLANS.find((p) => p.id === selectedPlan)?.storage}GB Storage
                </p>
                <p className="text-slate-400 text-sm">
                  ${PLANS.find((p) => p.id === selectedPlan)?.price}/month
                </p>
              </div>
            </div>

            {message && (
              <div className={`p-3 rounded-lg mb-4 text-sm text-center ${
                message.includes('Failed')
                  ? 'bg-red-950 border border-red-800 text-red-300'
                  : 'bg-green-950 border border-green-800 text-green-300'
              }`}>
                {message}
              </div>
            )}

            <div className="flex gap-3">
              <button
                onClick={() => setShowModal(false)}
                className="flex-1 bg-slate-700 hover:bg-slate-600 text-slate-50 py-2 rounded-lg transition-all"
              >
                Cancel
              </button>
              <button
                onClick={handleSubmitRequest}
                disabled={loading}
                className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg transition-all flex items-center justify-center disabled:opacity-50"
              >
                <Send className="w-4 h-4 mr-2" />
                {loading ? 'Sending...' : 'Send Request'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
