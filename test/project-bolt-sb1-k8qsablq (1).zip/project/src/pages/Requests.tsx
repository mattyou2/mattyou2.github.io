import { useState, useEffect } from 'react';
import { Check, X, Users, Loader, Crown } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase, Profile } from '../lib/supabase';

export default function Requests() {
  const { user, profile } = useAuth();
  const [users, setUsers] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [updating, setUpdating] = useState<string | null>(null);

  const isAdmin = user?.email === 'treurmattheo@gmail.com';

  useEffect(() => {
    if (isAdmin) {
      loadUsers();
    }
  }, [user, isAdmin]);

  const loadUsers = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;

      setUsers(data || []);
    } catch (error) {
      console.error('Error loading users:', error);
      alert('Failed to load users');
    } finally {
      setLoading(false);
    }
  };

  const handlePlanChange = async (userId: string, newPlan: 'free' | 'plus' | 'premium') => {
    setUpdating(userId);
    try {
      const storageMap = {
        free: 10737418240,
        plus: 53687091200,
        premium: 1099511627776,
      };

      const { error } = await supabase
        .from('profiles')
        .update({
          plan: newPlan,
          plan_updated_at: new Date().toISOString(),
          storage_limit: storageMap[newPlan],
        })
        .eq('id', userId);

      if (error) throw error;

      await loadUsers();
      alert(`User plan updated to ${newPlan}`);
    } catch (error) {
      console.error('Error updating user plan:', error);
      alert('Failed to update user plan');
    } finally {
      setUpdating(null);
    }
  };

  if (!isAdmin) {
    return (
      <div className="p-8">
        <div className="text-center py-12">
          <X className="w-16 h-16 text-red-400 mx-auto mb-4" />
          <p className="text-slate-50 text-lg">Access Denied</p>
          <p className="text-slate-400">Only the admin account can access this page</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-50 mb-2">User Management</h1>
        <p className="text-slate-400">Manage user accounts and assign subscription tiers</p>
      </div>

      {loading ? (
        <div className="text-center py-12 text-slate-400">
          <Loader className="w-8 h-8 animate-spin mx-auto mb-2" />
          Loading users...
        </div>
      ) : users.length === 0 ? (
        <div className="text-center py-12 bg-slate-900 rounded-lg border border-slate-700">
          <Users className="w-16 h-16 text-slate-600 mx-auto mb-4" />
          <p className="text-slate-50">No users found</p>
          <p className="text-slate-400">Users will appear here once they create accounts</p>
        </div>
      ) : (
        <div className="bg-slate-900 rounded-lg shadow-lg border border-slate-700 overflow-hidden">
          <table className="w-full">
            <thead className="bg-slate-800 border-b border-slate-700">
              <tr>
                <th className="px-6 py-4 text-left text-xs font-medium text-slate-400 uppercase">Username</th>
                <th className="px-6 py-4 text-left text-xs font-medium text-slate-400 uppercase">Current Plan</th>
                <th className="px-6 py-4 text-left text-xs font-medium text-slate-400 uppercase">Storage</th>
                <th className="px-6 py-4 text-left text-xs font-medium text-slate-400 uppercase">Created</th>
                <th className="px-6 py-4 text-left text-xs font-medium text-slate-400 uppercase">Change Plan</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-700">
              {users.map((userItem) => (
                <tr key={userItem.id} className="hover:bg-slate-800 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <p className="font-semibold text-slate-50">@{userItem.username}</p>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      {userItem.plan === 'free' && (
                        <span className="inline-block px-3 py-1 bg-blue-950 text-blue-300 rounded-full text-xs font-medium">
                          Free
                        </span>
                      )}
                      {userItem.plan === 'plus' && (
                        <span className="inline-block px-3 py-1 bg-amber-950 text-amber-300 rounded-full text-xs font-medium flex items-center gap-1">
                          <Crown className="w-3 h-3" />
                          Plus
                        </span>
                      )}
                      {userItem.plan === 'premium' && (
                        <span className="inline-block px-3 py-1 bg-purple-950 text-purple-300 rounded-full text-xs font-medium flex items-center gap-1">
                          <Crown className="w-3 h-3" />
                          Premium
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <p className="text-sm text-slate-400">
                      {Math.round(userItem.storage_limit / 1073741824)}GB
                    </p>
                  </td>
                  <td className="px-6 py-4">
                    <p className="text-sm text-slate-500">
                      {new Date(userItem.created_at).toLocaleDateString()}
                    </p>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex gap-2">
                      <button
                        onClick={() => handlePlanChange(userItem.id, 'free')}
                        disabled={updating === userItem.id || userItem.plan === 'free'}
                        className="px-3 py-1 bg-blue-950 hover:bg-blue-900 text-blue-300 rounded text-xs font-medium transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        Free
                      </button>
                      <button
                        onClick={() => handlePlanChange(userItem.id, 'plus')}
                        disabled={updating === userItem.id || userItem.plan === 'plus'}
                        className="px-3 py-1 bg-amber-950 hover:bg-amber-900 text-amber-300 rounded text-xs font-medium transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        Plus
                      </button>
                      <button
                        onClick={() => handlePlanChange(userItem.id, 'premium')}
                        disabled={updating === userItem.id || userItem.plan === 'premium'}
                        className="px-3 py-1 bg-purple-950 hover:bg-purple-900 text-purple-300 rounded text-xs font-medium transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        Premium
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
