import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Profile = {
  id: string;
  username: string;
  storage_used: number;
  storage_limit: number;
  plan: 'free' | 'plus' | 'premium';
  plan_updated_at: string;
  created_at: string;
};

export type File = {
  id: string;
  user_id: string;
  filename: string;
  file_size: number;
  file_type: string;
  storage_path: string;
  created_at: string;
  updated_at: string;
};

export type ApiKey = {
  id: string;
  user_id: string;
  key: string;
  name: string;
  permissions: {
    read: boolean;
    write: boolean;
    delete: boolean;
    edit: boolean;
  };
  created_at: string;
  last_used: string | null;
};

export type FileShare = {
  id: string;
  file_id: string;
  user_id: string;
  share_token: string;
  max_uses: number;
  current_uses: number;
  created_at: string;
  expires_at: string | null;
};

export type Message = {
  id: string;
  from_user_id: string;
  to_user_id: string;
  subject: string;
  content: string;
  file_id: string | null;
  read: boolean;
  created_at: string;
};

export type AiSettings = {
  user_id: string;
  sorting_enabled: boolean;
  image_generation_enabled: boolean;
  watermark_text: string;
  created_at: string;
  updated_at: string;
};

export type UpgradeRequest = {
  id: string;
  user_id: string;
  plan_type: 'plus' | 'premium';
  status: 'pending' | 'accepted' | 'rejected';
  created_at: string;
  updated_at: string;
};
